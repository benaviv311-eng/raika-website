#!/usr/bin/env python3
"""Run from the root of benaviv311-eng/raika-website after copying images."""
from pathlib import Path
import shutil

root=Path(__file__).resolve().parent
index=root/'index.html'
if not index.exists():
    raise SystemExit('index.html not found: place this script at the website repository root.')
for k in range(1,5):
    p=root/'world-characters'/'kenkyosha'/f'pose-{k}.webp'
    if not p.is_file():
        raise SystemExit(f'Missing approved image {p}')
html=index.read_text(encoding='utf-8')
card_anchor='    <article class="character world-character-card character--bard"'
data_anchor='  const data = {'
if 'data-character="kenkyosha"' not in html:
    assert card_anchor in html, 'World character card insertion point changed'
    card='''    <article class="character world-character-card character--kenkyosha" id="kenkyosha" hidden>
      <div class="character-media"><img loading="lazy" src="world-characters/kenkyosha/pose-1.webp" alt="Kenkyosha, the steampunk hedgehog investigator with a brass monocle, dark coat and burgundy waistcoat"></div>
      <div class="character-body">
        <div class="character-role">Royal Investigator · Lions Kingdom</div>
        <h3>Kenkyosha</h3>
        <p>A calculating hedgehog investigator who studies alchemical mixtures, records his findings and relies on his spiked defenses in danger.</p>
        <button type="button" class="profile-trigger" data-character="kenkyosha" aria-label="Explore Kenkyosha's four approved character poses">Explore character <span aria-hidden="true">↗</span></button>
      </div>
    </article>
'''
    html=html.replace(card_anchor, card+card_anchor,1)
if '    kenkyosha: {' not in html:
    assert data_anchor in html, 'Character profile data insertion point changed'
    info='''
    kenkyosha: {
      title: "Kenkyosha",
      role: "Royal Investigator · Lions Kingdom",
      quote: "Every observation reveals something.",
      description: "A hedgehog investigator with a mechanical monocle, a leather-bound notebook and an array of alchemical vials. Kenkyosha approaches his work methodically and uses his elaborate quills as a defensive shield.",
      traits: "Observation · Alchemy · Calculation · Defense",
      image: "world-characters/kenkyosha/pose-1.webp",
      alt: "Kenkyosha examining a glowing green alchemical syringe",
      variants: [
        {label: "The Scientist", image: "world-characters/kenkyosha/pose-1.webp", alt: "Kenkyosha examining a glowing green syringe and vial"},
        {label: "The Investigator", image: "world-characters/kenkyosha/pose-2.webp", alt: "Kenkyosha studying and writing in a leather-bound notebook"},
        {label: "Alchemical Attack", image: "world-characters/kenkyosha/pose-3.webp", alt: "Kenkyosha leaps and throws a green alchemical vial that bursts far from him"},
        {label: "Quill Defense", image: "world-characters/kenkyosha/pose-4.webp", alt: "Kenkyosha crouches and raises his quills as a defensive shield"}
      ]
    },'''
    html=html.replace(data_anchor, data_anchor+info,1)
index.write_text(html,encoding='utf-8')
print('Kenkyosha profile and four pose gallery added to', index)
