RAIKA — KENKYOSHA, FOUR APPROVED WEBSITE POSES

To publish in repository benaviv311-eng/raika-website:
1. Copy world-characters/kenkyosha/ into the repository root.
2. Copy patch_kenkyosha_site.py into the repository root.
3. Run: python patch_kenkyosha_site.py
4. Commit and push index.html and the four pose WebP files to main.

The script inserts a Kenkyosha card in the existing world-characters carousel and connects all four images to its profile-gallery component.
Approved pose images: 1 Scientist, 2 Investigator, 3 Alchemical Attack (corrected), 4 Quill Defense.
